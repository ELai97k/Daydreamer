# Daydreamer Discord bot
 Daydreamer was programmed using discord.py

 Python version: 3.10.7 (your version may be different) 
 pls change the Python version to yours in version.py in the cogs folder

# What can Daydreamer do?
 Daydreamer is a simple chatbot with an auto-response function.

 There are some basic commands like ping and test, and an 8ball command, but other than that, this is a very simple and basic Discord bot.