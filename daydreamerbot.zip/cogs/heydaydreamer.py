import discord
from discord.ext import commands

class HeyPrompts(commands.Cog):
    """'hey daydreamer' prompts and responses"""
    def __init__(self, client):
        self.client = client

    # embed
    @commands.command()
    async def heyprompts(self, ctx):
        if ctx.author == self.client.user:
            return
        if ctx.author.bot:
            return

        embed = discord.Embed (
            title = "List of available options when typing 'hey daydreamer'",
            color=0xffd966
        )
        # how are you
        embed.add_field(name="Ask how is Daydreamer", 
        value="**Prompts:** 'how are you', 'how are you doing'",
        inline=False)

        # features
        embed.add_field(name="Ask about Daydreamer's functions / features", 
        value="**Prompts:** 'what can you do', 'what are your features', 'what are your functions'",
        inline=False)

        # tell me about yourself
        embed.add_field(name="Ask Daydreamer to introduce himself", 
        value="**Prompts:** 'tell me about yourself', 'who are you', 'what are you'",
        inline=False)

        # what are you doing right now
        embed.add_field(name="Ask Daydreamer what he's doing", 
        value="**Prompts:** 'what are you doing right now', 'what are you doing now', 'what are you doing', 'what you doing', 'whatcha doin', 'whatcha doing', 'what'cha doin', 'what'cha doing', 'what are you doing currently', 'what are you currently doing'",
        inline=False)

        # talk to me
        embed.add_field(name="Make Daydreamer talk to you", 
        value="**Prompts:** 'talk to me', 'talk to me pls', 'pls talk to me', 'can you talk to me', 'can you pls talk to me', 'can ypu talk to me pls'",
        inline=False)
        
        # time
        embed.add_field(name="Ask Daydreamer about the time. (in GMT+8)",
        value="**Prompts:** 'whats the time', 'whats the time now', 'what's the time', 'what's the time now', 'what is the time', 'what is the time now', 'what time is it'",
        inline=False)

        # Isaac Asimov's Laws of Robotics
        embed.add_field(name="Ask Daydreamer about the Laws of Robotics",
        value="**Prompts:** 'tell me about robot laws', 'tell me about the robot laws', 'what are the robot laws', 'what are the laws of robotics'",
        inline=False)

        # you're / ur responses
        embed.add_field(name="you're / ur responses",
        value="stupid, dumb, dum, a dumbass, useless, not helpful, not helping, a good bot, a clever bot, a cleverbot, a smart bot",
        inline=False)

        await ctx.send(embed=embed)


def setup(client):
    client.add_cog(HeyPrompts(client))